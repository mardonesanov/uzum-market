package uz.app.persistance2.controller;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import uz.app.persistance2.db.Datasource;
import uz.app.persistance2.entity.User;

import java.io.IOException;
import java.util.List;
import java.util.Set;

@WebServlet("/user")
public class UserController extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        EntityManager em = Datasource.createEntityManager();
        try {
            em.getTransaction().begin();
            TypedQuery<User> query = em.createQuery("select u from User u where u.isActive = true", User.class);
            List<User> resultList = query.getResultList();
            req.setAttribute("users", resultList);
        } finally {
            em.getTransaction().commit();
        }
        req.getRequestDispatcher("/views/user.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String name = req.getParameter("name");
        String number = req.getParameter("phoneNumber");
        String password = req.getParameter("password");
        Integer age = Integer.parseInt(req.getParameter("age"));
        EntityManager em = Datasource.createEntityManager();

        User users = User.builder()
                .name(name)
                .phoneNumber(number)
                .password(password)
                .isActive(true)
                .age(age)
                .build();
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        Validator validator = factory.getValidator();
        Set<ConstraintViolation<User>> validate = validator.validate(users);
        validate.forEach(userConstraintViolation -> {
            System.out.println(userConstraintViolation.getPropertyPath());
            System.out.println(userConstraintViolation.getMessageTemplate());
        });

        try {
            em.getTransaction().begin();
            em.persist(users);
        } finally {
            em.getTransaction().commit();

        }
        resp.sendRedirect("/user");

    }
}
