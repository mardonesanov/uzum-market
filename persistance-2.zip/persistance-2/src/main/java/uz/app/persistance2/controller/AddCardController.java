package uz.app.persistance2.controller;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import uz.app.persistance2.db.Datasource;
import uz.app.persistance2.entity.Card;
import uz.app.persistance2.entity.User;
import uz.app.persistance2.payload.Type;

import java.io.IOException;

@WebServlet("/add-card")
public class AddCardController extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String id = req.getParameter("id");
        req.setAttribute("userId", id);
        req.setAttribute("types", Type.values());
        req.getRequestDispatcher("/views/add-card.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String userId = req.getParameter("userId");
        String number = req.getParameter("number");
        String expireDate = req.getParameter("expireDate");
        String type = req.getParameter("type");
        System.out.println("userId "+userId);
        EntityManager em = Datasource.createEntityManager();
        try {
            em.getTransaction().begin();
            Query query = em.createNamedQuery("byId");
            query.setParameter("id", userId);
            User user = (User) query.getSingleResult();

            Card card = Card.builder()
                    .number(number)
                    .balance(0.0)
                    .expireDate(expireDate)
                    .type(Type.valueOf(type))
                    .user(user)
                    .build();
            em.persist(card);
        }finally {
            em.getTransaction().commit();
        }
        resp.sendRedirect("/user");
    }
}
