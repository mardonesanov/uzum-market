package uz.app.persistance2.entity;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Entity
@Table(name = "users")
@AllArgsConstructor
@NoArgsConstructor
@Builder
@NamedQuery(name = "byId", query = "select u from User u where u.id=:id")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String name;
    @Min(value = 18, message = "baraka topgu oldin 18 ga kir")
    private Integer age;
    @NotBlank(message = "raqam bo'sh bo'lmasin")
    private String phoneNumber;
    @Size(min = 8, max = 16,message = "parol minimum 8 ta harf va maximum 16 ta xarf bo'lishi kerak")
    private String password;
    private Boolean isActive;
    @OneToMany(mappedBy = "user")
    private List<Card> cards;
}
