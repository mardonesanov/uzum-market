package uz.app.persistance2.controller;

import jakarta.persistence.EntityManager;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import uz.app.persistance2.db.Datasource;
import uz.app.persistance2.entity.Card;
import uz.app.persistance2.entity.User;

import java.io.IOException;
import java.util.List;

@WebServlet("/show-card")
public class ShowCardController extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Integer id = Integer.parseInt(req.getParameter("id"));
        EntityManager em = Datasource.createEntityManager();

        User user = (User)em.createNamedQuery("byId").setParameter("id",id).getSingleResult();

        List<Card> resultList =  em.createNamedQuery("byUserId",Card.class).setParameter("userId", id).getResultList();
        System.out.println("data proceed");
        System.out.println("we are gonna see cards list");
        req.setAttribute("cards", resultList);
        req.getRequestDispatcher("/views/show-card.jsp").forward(req, resp);
    }
}
