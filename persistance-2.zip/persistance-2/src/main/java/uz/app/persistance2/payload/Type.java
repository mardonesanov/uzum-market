package uz.app.persistance2.payload;

public enum Type {
    HUMO,
    UZCARD,
    VISA,
    MASTERCARD,
    UNION_PAY
}
