package uz.app.persistance2.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import uz.app.persistance2.payload.Type;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
@NamedQuery(name = "byUserId",query = "select c from Card c where c.user.id = :userId")
//@NamedNativeQuery(name = "byUserId", query = """
//select c.* from card c
//    join users_card us on c.id= us.cards_id
//    join users u on u.id=us.user_id
//           where u.id = :userId
//""",
//resultClass = Card.class)
public class Card {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String number;
    private String expireDate;
    private Double balance;

    @Enumerated(EnumType.STRING)
    private Type type;

    @ManyToOne
    private User user;

}
